# 默认八层框架：拆解 Agent 项目的分析手册

用户未自带框架时使用本框架。每层包含：定义、要回答的问题清单、常见实现模式、文件名信号。

---

## 01 用户入口层

**定义**：请求从用户到系统的第一公里——前端交互、API 端点、会话入口。

**要回答的问题**：
- 请求怎么进来？同步 HTTP 还是异步任务 + 流式推送（SSE/WebSocket）？
- 前端怎么提交、怎么收进度？有没有 task_id 之类的会话标识复用机制？
- 入口有哪些参数（effort 档位、模型选择、循环次数）？参数在哪一侧定义？
- 有没有多条通道并存（新旧通道、SDK 通道 + 自建通道）？为什么？

**常见实现模式**：React/Vue 前端 + FastAPI/Flask 后端；LangGraph SDK `useStream`；自研 SSE hook；`POST /api/xxx` 立即返回 task_id 的异步模式。

**文件名信号**：`app.py`、`main.py`、`server.py`、`App.tsx`、`pages/`、`components/`、`api.ts`、`use*Stream.ts`、`langgraph.json`。

---

## 02 任务理解层

**定义**：把模糊的自然语言需求转成明确、可执行的任务定义。

**要回答的问题**：
- 有没有需求澄清环节（反问、澄清循环、HITL 确认）？还是直接开干？
- 意图识别怎么做？关键词短路 + LLM 兜底是常见组合。
- 理解阶段产出什么结构化字段？这些字段传给下游哪一层？（典型：时效敏感度 → 知识库 TTL）
- LLM 输出怎么解析成结构化数据？解析失败怎么兜底？

**常见实现模式**：澄清循环 prompt（进度条/五要素映射）；`JsonAgent` + Pydantic schema 做意图识别；```markdown/```json 围栏 + 正则/括号配对回溯做输出提取。

**文件名信号**：`graph.py` 中的 plan/clarify 节点、`prompts.py`、`tools_and_schemas.py`、`schemas.py`、`post.py`。

---

## 03 规划与编排层

**定义**：决定执行顺序、分支、循环、并行——整个系统的骨架。

**要回答的问题**：
- 用什么编排？LangGraph StateGraph / 手写状态机 / 简单 pipeline？
- 是单体图还是子图/多 Agent？为什么拆？
- 并行怎么做（LangGraph `Send` 扇出、asyncio.gather、线程池）？结果怎么归并（reducer）？
- 循环退出条件是什么？有没有防死循环的硬上限？
- 状态怎么定义和传递（TypedDict + reducer、共享 state schema）？

**常见实现模式**：LangGraph 主图 + 子图；`Send` map-reduce 扇出 + `operator.add` 归并；`config_schema` 注入运行时配置（优先级：env > configurable > default）。

**文件名信号**：`graph.py`、`flow.py`、`orchestrator.py`、`state.py`、`configuration.py`、`sub_agents/`、`agents/`。

---

## 04 工具调用层

**定义**：系统伸手到外部世界的地方——搜索、API、数据库、文件读写。

**要回答的问题**：
- 调了什么外部能力？怎么调的？
- **关键判别**：LLM 自主决定调工具（function calling / tool binding）还是流程写死（workflow 编排）？如实回答，这是高频追问点。
- 有没有缓存？key 怎么设计（归一化 + hash）？TTL 多少？
- 有没有限流（令牌桶/漏桶）？QPS 多少？
- 失败怎么处理：重试几次、退避策略、异常分类（瞬时 vs 永久）、降级方案？
- 结果怎么解析和容错（多路径探测、防御性解析）？

**常见实现模式**：MCP 应用调用（如百炼 `Application.call`）；Redis 缓存 + 内存降级；令牌桶 RateLimiter（同步/异步双版本）；交叉编码器精排（reranker）；HTTP 状态码 → 语义异常分类（429→重试、401/403→零重试快失败）。

**文件名信号**：`base_agent.py`、`tools.py`、`tools_and_schemas.py`、`mcp*.py`、`search*.py`、`cache*.py`、`reranker.py`、`exceptions.py`。

---

## 05 知识与记忆层

**定义**：跨会话/跨任务沉淀和检索知识，为生成提供依据。

**要回答的问题**：
- 有几种记忆？各自管什么？（典型四类：会话状态 checkpoint / 长期语义知识向量库 / 结果缓存 / 关系型账号数据）
- 知识怎么写入（什么时机、谁抽取、什么格式）？怎么读取（什么时机、怎么注入 prompt）？
- 有没有知识老化机制（TTL、置信度时间衰减、按类别差异化过期）？
- 检索是单阶段还是双阶段（粗召回 + 精排）？
- 知识库挂了主流程还能跑吗（哨兵降级）？

**常见实现模式**：Milvus/PGVector/Chroma 向量库 + embedding 模型；LLM 事实抽取（带 confidence + 类别）；`CATEGORY_TTL` 按类别过期；LangGraph Checkpointer（Redis/Postgres Saver）；知识库读写形成"写→读→衰"闭环。

**文件名信号**：`kb/`、`memory/`、`store.py`、`fact_store.py`、`extractor.py`、`lifecycle.py`、`checkpointer`、`db/`。

---

## 06 执行与状态管理层

**定义**：任务怎么排队跑、状态怎么持久化、进度怎么实时推、中断怎么恢复。

**要回答的问题**：
- 长任务怎么执行：同步阻塞 / 任务队列 / 后台协程？
- 用什么队列（Redis Streams / Celery / RabbitMQ）？为什么？
- 状态持久化怎么做（checkpoint、thread_id）？中断后怎么续跑？
- 进度怎么推给前端（SSE/WebSocket/轮询）？事件从哪来？
- LLM 流式 token 怎么一路透传到前端（回调注入 → 事件流 → SSE → 打字机）？
- 子图/子任务的内部事件怎么暴露给外部（事件名翻译）？

**常见实现模式**：Redis Streams（XADD/XREADGROUP/XACK）+ 进程内 asyncio worker 协程；`AsyncRedisSaver` checkpoint（thread_id = task_id）；`subgraphs=True` 穿透子图事件；`_emit_token` 回调注入实现流式透传；HITL 用"同 task_id 复用 checkpoint"恢复。

**文件名信号**：`task_queue.py`、`worker.py`、`queue.py`、`events.py`、`stream*.py`。

---

## 07 安全与权限层

**定义**：谁能用、数据隔离、输入防护、成本容量防护。

**要回答的问题**：
- 认证怎么做（session/JWT/OAuth）？密码怎么存（bcrypt）？
- 有几个入口要鉴权？是否共用同一份会话？（常见坑：自建 API 有鉴权但框架原生端点裸奔）
- 数据隔离怎么做（user_id 注入、唯一约束）？
- 配置防篡改：哪些字段禁止前端注入（模型列表、系统 prompt）？
- 容量防护：参数上限校验、max_tokens、RPM/TPM 限流——**哪些是已落地、哪些是文档里的规划**？如实区分。
- 前端 XSS 防护（react-markdown vs dangerouslySetInnerHTML）。

**常见实现模式**：Redis session + HttpOnly Cookie + SameSite；FastAPI 中间件白名单；框架平台级认证（LangGraph `@auth.authenticate`）；`Configuration` 解析时显式跳过敏感字段。

**文件名信号**：`auth/`、`middleware.py`、`session.py`、`models.py`（User 表）、安全设计文档。

---

## 08 评估与反馈层

**定义**：运行时自我修正 + 离线质量度量。

**要回答的问题**：
- 在线有几个自我修正闭环（搜够没/写好没/计划满意没）？退出条件是什么？
- 闭环的退出是否只信 LLM 自评？有没有确定性规则兜底（评分阈值 + 最大次数硬上限）？为什么需要兜底（Critic 和 Writer 可能同模型，"自己审自己"有偏差）？
- 离线评估怎么做（LLM-as-Judge / 人工评审 / 无）？评哪些维度？有没有幻觉检测？
- 评估中间产物（原始搜索结果）丢失了怎么补（monkey-patch 插桩）？
- 评估结果会回流优化系统吗？还是"两张皮"？

**常见实现模式**：Critic↔Writer 辩论环（结构化 CritiqueResult + 多重退出保险）；Reflection 节点 + max_loops 硬上限；LLM-as-Judge 双模式（e2e 终稿打分 + comp 组件级打分）；Pydantic clamp 防乱打分。

**文件名信号**：`eval/`、`judge.py`、`evaluator.py`、`critic*`、writer 子图中的评审节点、`test/`。

---

## 层间传参的典型模式（必须找）

拆解时主动寻找以下跨层信号，这是架构分析的最大价值点：

1. **理解层 → 知识层**：意图识别产出的语义字段（时效敏感度、领域、深度要求）约束检索行为（TTL 阈值、top_k、过滤条件）。
2. **入口层 → 执行层**：task_id 复用为 checkpoint thread_id，把"会话"和"任务执行"用同一个 ID 串起来。
3. **工具层 → 知识层**：工具调用产物（搜索摘要）是知识库的水源（写入时机 = 工具调用完成后）。
4. **编排层 ↔ 评估层**：编排的条件边本身就是在线评估（critique 循环、辩论环退出条件），评估不是外挂是流程一部分。

## 架构类型判别（如实回答）

| 类型 | 特征 | 判别方法 |
|------|------|---------|
| workflow 编排型 | 流程写死在代码里，LLM 只填充内容 | 代码里没有 tool_call/function calling，工具在固定节点被调用 |
| agentic 自主决策型 | LLM 自主决定调什么工具、什么时候调 | 存在 tool binding + 模型返回 tool_calls 的循环 |

大多数生产级 Agent 项目是 workflow 编排型或其变体，如实说明并讲清理由（可控性、可测试性、成本可预期）即可，不是减分项。
